<?php

namespace App\Http\Controllers;

use App\Http\Requests\StorePermissionRequest;
use App\Services\PermissionService;
use Illuminate\Http\RedirectResponse;
use Illuminate\View\View;

class PermissionController extends Controller
{
    public function __construct(protected PermissionService $permissionService) {}

    public function index(): View
    {
        $permissions = $this->permissionService->getAllPermissions();

        return view('permissions.index', compact('permissions'));
    }

    public function create(): View
    {
        return view('permissions.create');
    }

    public function store(StorePermissionRequest $request): RedirectResponse
    {
        $this->permissionService->createPermission($request->validated());

        return redirect()
            ->route('permissions.index')
            ->with('success', 'Permission created successfully.');
    }

    public function edit(int $id): View
    {
        $permission = $this->permissionService->findPermission($id);

        abort_if(!$permission, 404, 'Permission not found.');

        return view('permissions.edit', compact('permission'));
    }

    public function update(StorePermissionRequest $request, int $id): RedirectResponse
    {
        $this->permissionService->updatePermission($id, $request->validated());

        return redirect()
            ->route('permissions.index')
            ->with('success', 'Permission updated successfully.');
    }

    public function destroy(int $id): RedirectResponse
    {
        $this->permissionService->deletePermission($id);

        return redirect()
            ->route('permissions.index')
            ->with('success', 'Permission deleted successfully.');
    }
}
