<?php

namespace App\Services;

use App\Repositories\Interfaces\PermissionRepositoryInterface;
use Illuminate\Database\Eloquent\Collection;
use Spatie\Permission\Models\Permission;

class PermissionService
{
    public function __construct(
        protected PermissionRepositoryInterface $permissionRepository
    ) {}

    public function getAllPermissions(): Collection
    {
        return $this->permissionRepository->getAll();
    }

    public function findPermission(int $id): ?Permission
    {
        return $this->permissionRepository->findById($id);
    }

    public function createPermission(array $data): Permission
    {
        return $this->permissionRepository->create([
            'name'       => $data['name'],
            'guard_name' => $data['guard_name'] ?? 'web',
        ]);
    }

    public function updatePermission(int $id, array $data): bool
    {
        return $this->permissionRepository->update($id, [
            'name'       => $data['name'],
            'guard_name' => $data['guard_name'] ?? 'web',
        ]);
    }

    public function deletePermission(int $id): bool
    {
        return $this->permissionRepository->delete($id);
    }
}
