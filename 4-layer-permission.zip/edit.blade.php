@extends('layouts.app')

@section('title', 'Edit Permission')

@section('content')
<div class="container-fluid py-4">
    <div class="row justify-content-center">
        <div class="col-md-6">

            {{-- Page Header --}}
            <div class="d-flex align-items-center justify-content-between mb-4">
                <div>
                    <h4 class="mb-0 fw-bold">Edit Permission</h4>
                    <nav aria-label="breadcrumb">
                        <ol class="breadcrumb mb-0 small">
                            <li class="breadcrumb-item">
                                <a href="{{ route('permissions.index') }}">Permissions</a>
                            </li>
                            <li class="breadcrumb-item active">Edit — {{ $permission->name }}</li>
                        </ol>
                    </nav>
                </div>
                <a href="{{ route('permissions.index') }}" class="btn btn-outline-secondary btn-sm">
                    <i class="fas fa-arrow-left me-1"></i> Back
                </a>
            </div>

            {{-- Errors --}}
            @if ($errors->any())
                <div class="alert alert-danger alert-dismissible fade show">
                    <strong><i class="fas fa-exclamation-circle me-1"></i> Fix the following:</strong>
                    <ul class="mb-0 mt-2">
                        @foreach ($errors->all() as $error)
                            <li>{{ $error }}</li>
                        @endforeach
                    </ul>
                    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                </div>
            @endif

            {{-- Form Card --}}
            <div class="card shadow-sm border-0">
                <div class="card-header bg-white border-bottom py-3">
                    <h6 class="mb-0 fw-semibold text-muted">
                        <i class="fas fa-key me-2 text-warning"></i>Update Permission
                    </h6>
                </div>

                <div class="card-body p-4">
                    <form action="{{ route('permissions.update', $permission->id) }}"
                          method="POST"
                          novalidate>
                        @csrf
                        @method('PUT')

                        <div class="row g-3">

                            {{-- Permission Name --}}
                            <div class="col-12">
                                <label for="name" class="form-label fw-medium">
                                    Permission Name <span class="text-danger">*</span>
                                </label>
                                <input
                                    type="text"
                                    id="name"
                                    name="name"
                                    value="{{ old('name', $permission->name) }}"
                                    class="form-control @error('name') is-invalid @enderror"
                                    placeholder="e.g. create-user"
                                    autofocus
                                />
                                @error('name')
                                    <div class="invalid-feedback">{{ $message }}</div>
                                @enderror
                                <div class="form-text">Use lowercase with hyphens, e.g. <code>create-user</code></div>
                            </div>

                            {{-- Guard Name --}}
                            <div class="col-12">
                                <label for="guard_name" class="form-label fw-medium">Guard Name</label>
                                <select id="guard_name" name="guard_name"
                                        class="form-select @error('guard_name') is-invalid @enderror">
                                    <option value="web" {{ old('guard_name', $permission->guard_name) === 'web' ? 'selected' : '' }}>web</option>
                                    <option value="api" {{ old('guard_name', $permission->guard_name) === 'api' ? 'selected' : '' }}>api</option>
                                </select>
                                @error('guard_name')
                                    <div class="invalid-feedback">{{ $message }}</div>
                                @enderror
                            </div>

                        </div>

                        <hr class="my-4">

                        {{-- Meta Info --}}
                        <div class="text-muted small mb-3">
                            <i class="fas fa-clock me-1"></i>
                            Created: {{ $permission->created_at->format('d M Y, h:i A') }}
                            &nbsp;&bull;&nbsp;
                            Updated: {{ $permission->updated_at->format('d M Y, h:i A') }}
                        </div>

                        <div class="d-flex justify-content-end gap-2">
                            <a href="{{ route('permissions.index') }}" class="btn btn-secondary">
                                <i class="fas fa-times me-1"></i> Cancel
                            </a>
                            <button type="submit" class="btn btn-primary">
                                <i class="fas fa-save me-1"></i> Update Permission
                            </button>
                        </div>

                    </form>
                </div>
            </div>

        </div>
    </div>
</div>
@endsection
