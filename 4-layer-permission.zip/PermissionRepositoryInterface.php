<?php

namespace App\Repositories\Interfaces;

use Illuminate\Database\Eloquent\Collection;
use Spatie\Permission\Models\Permission;

interface PermissionRepositoryInterface
{
    public function getAll(): Collection;

    public function findById(int $id): ?Permission;

    public function create(array $data): Permission;

    public function update(int $id, array $data): bool;

    public function delete(int $id): bool;
}
