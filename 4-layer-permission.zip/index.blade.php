@extends('layouts.app')

@section('title', 'Permissions')

@section('content')
<div class="container-fluid py-4">

    {{-- Page Header --}}
    <div class="d-flex align-items-center justify-content-between mb-4">
        <div>
            <h4 class="mb-0 fw-bold">Permissions</h4>
            <p class="text-muted small mb-0">Manage all system permissions</p>
        </div>
        <a href="{{ route('permissions.create') }}" class="btn btn-success btn-sm">
            <i class="fas fa-plus me-1"></i> Add Permission
        </a>
    </div>

    {{-- Flash Messages --}}
    @if (session('success'))
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            <i class="fas fa-check-circle me-1"></i> {{ session('success') }}
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    @endif

    @if (session('error'))
        <div class="alert alert-danger alert-dismissible fade show" role="alert">
            <i class="fas fa-exclamation-circle me-1"></i> {{ session('error') }}
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    @endif

    {{-- Table Card --}}
    <div class="card shadow-sm border-0">
        <div class="card-header bg-white border-bottom py-3 d-flex align-items-center justify-content-between">
            <h6 class="mb-0 fw-semibold text-muted">
                <i class="fas fa-key me-2 text-warning"></i>All Permissions
                <span class="badge bg-secondary ms-1">{{ $permissions->count() }}</span>
            </h6>
        </div>

        <div class="card-body p-0">
            @if ($permissions->isEmpty())
                <div class="text-center py-5 text-muted">
                    <i class="fas fa-key fa-3x mb-3 d-block opacity-25"></i>
                    No permissions found. <a href="{{ route('permissions.create') }}">Create one now</a>.
                </div>
            @else
                <div class="table-responsive">
                    <table class="table table-hover align-middle mb-0">
                        <thead class="table-light">
                            <tr>
                                <th class="ps-4">#</th>
                                <th>Permission Name</th>
                                <th>Guard</th>
                                <th>Created</th>
                                <th class="text-end pe-4">Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            @foreach ($permissions as $index => $permission)
                                <tr>
                                    <td class="ps-4 text-muted small">{{ $index + 1 }}</td>

                                    <td>
                                        <span class="badge bg-warning-subtle text-warning border border-warning-subtle px-3 py-2">
                                            <i class="fas fa-key me-1"></i>{{ $permission->name }}
                                        </span>
                                    </td>

                                    <td>
                                        <span class="badge bg-light text-secondary border">
                                            {{ $permission->guard_name }}
                                        </span>
                                    </td>

                                    <td class="text-muted small">
                                        {{ $permission->created_at->format('d M Y') }}
                                    </td>

                                    <td class="text-end pe-4">
                                        <a href="{{ route('permissions.edit', $permission->id) }}"
                                           class="btn btn-sm btn-outline-primary me-1"
                                           title="Edit">
                                            <i class="fas fa-edit"></i>
                                        </a>

                                        <form action="{{ route('permissions.destroy', $permission->id) }}"
                                              method="POST"
                                              class="d-inline"
                                              onsubmit="return confirm('Delete permission: {{ addslashes($permission->name) }}?')">
                                            @csrf
                                            @method('DELETE')
                                            <button type="submit"
                                                    class="btn btn-sm btn-outline-danger"
                                                    title="Delete">
                                                <i class="fas fa-trash-alt"></i>
                                            </button>
                                        </form>
                                    </td>
                                </tr>
                            @endforeach
                        </tbody>
                    </table>
                </div>
            @endif
        </div>
    </div>

</div>
@endsection
